<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model
{
	
/*
public function get_users() {

//$this->db->where([ 'id'=> $user_id, 'username' => $username]);
$query = $this->db->get('users');
return $query->result();




/*
 $config['hostname'] = "localhost";
 $config['username'] = "root";
 $config['password'] = "";
 $config['database'] = "errand_db";

$connection = $this->load->database($config); */
//$query = $this->db->query("SELECT * FROM users");




//return $query->num_rows(); - shows number of rows
//return $query->num_fields();// shows number of fileds(columns)


/*

}

public function createUser($data) {

$this->db->insert('users', $data);

}


public function updateUser($data, $id) {

$this->db->where(['id'=> $id]);
$this->db->update('users', $data);

}

public function deleteUser($id){
	$this->db->where(['id' => $id]);
	$this->db->delete('users');
}
*/
public function login_user($username, $password) {

    $this->db->where('username', $username);
    $this->db->where('password', $password);

    $result = $this->db->get('users');

    if($result->num_rows() == 1){

   return $result->row(0)->id;


    } else{

    	return false;
    }
  
 


}

public function create_user() {
 
 $username = $this->input->post('username');
 
 $this->db->where('username', $username);
 $results = $this->db->get('users');
 if($results->num_rows() > 0) {

    echo "<div class = 'jumbotron'>"."<h1>". "Username exist"."</h1>";
    //echo "<a href = ";
 }
else{


 $data = array(

    'first_name'  => $this->input->post('first_name'),
    'last_name'   => $this->input->post('last_name'),
    'email'       => $this->input->post('email'),
    'username'    => $this->input->post('username'),
    'password'    => $this->input->post('password'),

    );


$insert_data = $this->db->insert('users', $data);
return $insert_data;

}



	
}

}
 


 ?>