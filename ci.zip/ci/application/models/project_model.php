<?php
class Project_model extends CI_Model {

public function get_project($id) {

$this->db->where('id', $id);
$query = $this->db->get('projects');
return $query->row();

}	


public function get_all_projects ($user_id) {

$this->db->where('project_user_id', $user_id);
$query = $this->db->get('projects');
return $query->result();

}

  
  public function get_projects() {

  	$query = $this->db->get('projects');

  	return $query->result();



  }

  public function create_project ($data) {
 
    $insert_query = $this->db->insert('projects', $data);
    return $insert_query;
    
}

 public function edit_project($id, $data){
$this->db->where('id', $id);
$this->db->update('projects', $data);
return true;

 }

 public function delete_project($id) {
   
       $this->db->where('id', $id);
       $this->db->delete('projects');   
 }

 public function get_projects_info($id){

   $this->db->where('id', $id);
   $get_data = $this->db->get('projects');
   return $get_data->row();

 }

 public function get_projects_tasks($id, $active = true){
   
    $this->db->select('
    
    task.task_name,
    task.task_body,
    task.id as task_id,
    projects.project_name,
    projects.project_body        

     

      ');

    $this->db->from('task');
    $this->db->join('projects', 'projects.id = task.project_id');
    $this->db->where('task.project_id', $id);
    if($active == true) {

       $this->db->where('task.status', 0); 

    }else{

      $this->db->where('task.status', 1);
    }
    $query = $this->db->get();
    if($query->num_rows() < 1) {
           
           return FALSE;

    }

    return $query->result();

 }

public function delete_project_task($id) {

  $this->db->where('project_id', $id);
  $query  = $this->db->delete('task'); 
  return $query;
    

}

}

?>