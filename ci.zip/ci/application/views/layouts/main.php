<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.css">

</head>
<body>



 <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?php echo base_url();?>">Panga Project </a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="<?php echo base_url();?>">Home </a></li>
            <li><a href="<?php echo base_url();?>users/register">Register</a></li>
            <li><a href="<?php echo base_url();?>projects/index">Projects</a></li>
           
          </ul>
         <?php 
         if($this->session->userdata('logged_in')):

               ?>

          <ul class="nav navbar-nav navbar-right">
            
            <!--<li><a href="../navbar-static-top/">Static top</a></li> -->
            <li class="active"><a href="<?php echo base_url(); ?>Users/logout">Logout <span class="sr-only">(current)</span></a></li>
          </ul>
        <?php endif; ?>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

<BR/><BR/><BR/><BR/><BR/>


<div class="container">

   <div class ="col-xs-3"> 
   <?php $this->load->view('users/login_view.php'); ?>

   </div> 

       <div class="col-xs-9">
       	
<?php 

$this->load->view($main_view);


?>

       </div>


</div>

</body>
</html>