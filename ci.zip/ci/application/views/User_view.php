<!DOCTYPE html>
<html>
<head>
	<title>User_view</title>
</head>
<body>
<h1>
	<?php


//echo $results;



foreach ($results as $object) {
	//echo $object->id. '<br/>';
	echo $object->username. '<br/>';
	//echo $object->password. '<br/>';
}


	  ?>


</h1>




</body>
</html>